# Handoff: Eddie Barretta — Hero Refresh + New Favicon

## Overview
Design review of eddiebarretta.com (repo: `bensubercaseaux/eddiebarretta`, Next.js 16 + Tailwind v4 + Motion) produced two approved changes to implement in the existing codebase:

1. **Replace the spinning-vinyl hero visual** with a new "sound-waves" mark: an EB monogram disc with slow concentric ripple rings.
2. **Replace the favicon / app icon** with a matching EB pulse-disc icon (`icon.png` in this bundle → `app/icon.png` in the repo).

Everything else on the site stays as-is.

## About the Design Files
`Eddie Barretta Site.dc.html` (+ `support.js`, `public/`) is a **design reference built in HTML** — a prototype recreating the live homepage with the new hero applied. It is NOT production code. Recreate the approved changes inside the existing Next.js codebase using its established patterns (Tailwind classes, `motion/react`, the existing `components/Hero.tsx`).

## Fidelity
**High-fidelity.** All colors, sizes, and timings below are exact and match the repo's existing design tokens (`app/globals.css`). Implement pixel-perfectly.

## Change 1 — Hero visual: "sound-waves"

Replaces the `<Vinyl />` component usage in `components/Hero.tsx` (both the desktop right column and the mobile watermark, which should use the same mark).

### Layout
Same slot as the current vinyl: right grid column of the hero (`lg:grid-cols-[1.05fr_0.95fr]`), centered, square container `width: clamp(20rem, 28vw, 32rem)`, `aspect-ratio: 1`.

### Anatomy (container is `position: relative; display: grid; place-items: center`)
1. **Ripple rings ×3** — absolutely positioned spans filling the container (`inset: 0`):
   - `border-radius: 9999px`
   - `border: 1px solid rgba(154, 100, 255, 0.7)`  (accent-bright at 70%)
   - Animation: `ripple 4.5s ease-out infinite`, staggered delays `0s / 1.5s / 3s`
   - Keyframes:
     ```css
     @keyframes ripple {
       0%   { transform: scale(0.45); opacity: 0.7; }
       100% { transform: scale(1.35); opacity: 0; }
     }
     ```
2. **Center disc** — `38%` width/height of the container, `border-radius: 9999px`:
   - Background: `radial-gradient(circle at 35% 30%, #1b1830, #09080f)` (surface-2 → ink)
   - Border: `1px solid #221f33` (line)
   - Shadow: `0 0 80px rgba(124, 43, 255, 0.35)` (accent glow)
3. **EB monogram** inside the disc, centered:
   - Font: Syne, weight 800, `font-size: clamp(2.5rem, 4vw, 4rem)`, `letter-spacing: -0.03em`
   - Color: `#9a64ff` (accent-bright)

### Motion notes
- Gate the ripple animation behind `prefers-reduced-motion: reduce` (same pattern as the existing `.eq-bar` / `.animate-glow` rules in `globals.css`) — show the disc static with a single non-animated ring at `scale(1)`, low opacity.
- The existing violet `.glow.animate-glow` blob behind the hero stays unchanged.
- Delete the `Vinyl` component and its `motion` rotate loop once replaced; `public/hero.png` remains in use as the OG/social image unless later replaced.

### Explored-but-not-chosen alternatives (in the prototype's Tweaks, for reference only)
`vinyl` (original), `eq-monogram` (outlined EB + equalizer bars), `photo` (duotone booth photo). The client approved **sound-waves**. Do not implement the others.

## Change 2 — Favicon / app icon
- File: `icon.png` in this bundle (512×512 PNG, rendered from the live design in Syne 800).
- Replace `app/icon.png` in the repo — Next.js file-convention picks it up automatically as the favicon.
- Visual: violet `EB` (Syne 800, #9a64ff) on a dark radial disc (#1b1830 → #09080f) with two thin ripple rings (rgba(154,100,255,.55) and .28) and a soft violet glow, on #09080f ground.
- Optional: also use it for `apple-icon.png`; keep `opengraph-image.tsx` generators as they are.

## Design Tokens (from `app/globals.css` — already in the repo)
- `--ink: #09080f`, `--surface: #131120`, `--surface-2: #1b1830`
- `--fg: #efedf6`, `--muted: #a6a2bc`, `--faint: #847f9c`, `--line: #221f33`
- `--accent: #7c2bff`, `--accent-bright: #9a64ff`
- Fonts: Syne (600/700/800, display), Space Grotesk (400/500/700, body) — already loaded via `next/font/google`.

## Interactions & State
No new state. The hero visual is purely decorative (`aria-hidden` on the rings; the disc can carry `role="img"` + `aria-label="Eddie Barretta — EB mark"`).

## Assets
- `icon.png` — new favicon (this bundle, generated for this handoff)
- `public/hero.png`, `public/eddieb_profile_pic.webp`, `public/transcend-v2.jpg` — copied from the repo, included so the prototype renders; already exist in the codebase.

## Files in this bundle
- `README.md` — this document
- `icon.png` — new favicon, drop-in replacement for `app/icon.png`
- `Eddie Barretta Site.dc.html` + `support.js` — HTML design reference of the full homepage with the new hero (open in a browser; the Tweaks metadata at the bottom of the file lists the hero variants)
- `public/` — image assets used by the reference

## Notes for the implementer
- The prototype's mix/tracklist/show content is placeholder — the real site sources mixes live from SoundCloud RSS and shows from `lib/shows-store.ts`. Do not copy content from the prototype.
- Only the hero visual and favicon change; nav, copy, sections, and layout are already correct in the repo.
